import { Button } from "@/components/ui/button";
import { MapPin, Phone, Mail, Instagram, Facebook } from "lucide-react";

const ContactSection = () => {
  return (
    <section id="contato" className="py-20 px-6 bg-brillia-light">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-inter-semibold text-brillia-primary mb-6">
            Vamos Conversar?
          </h2>
          <p className="text-xl font-inter-medium text-brillia-secondary max-w-3xl mx-auto">
            Estamos prontos para transformar sua presença digital. Entre em contato e vamos começar hoje mesmo!
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-12">
          <div className="space-y-8">
            <div className="bg-white p-8 rounded-xl shadow-sm border border-border">
              <h3 className="text-2xl font-inter-semibold text-brillia-primary mb-6">
                Informações de Contato
              </h3>
              
              <div className="space-y-6">
                <div className="flex items-center space-x-4">
                  <Phone className="w-6 h-6 text-primary" />
                  <div>
                    <p className="font-inter-semibold text-brillia-primary">WhatsApp</p>
                    <p className="text-brillia-secondary font-inter-medium">(43) 98850-8487</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <Mail className="w-6 h-6 text-primary" />
                  <div>
                    <p className="font-inter-semibold text-brillia-primary">Email</p>
                    <p className="text-brillia-secondary font-inter-medium">atendimento@brilliacode.com</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <MapPin className="w-6 h-6 text-primary" />
                  <div>
                    <p className="font-inter-semibold text-brillia-primary">Localização</p>
                    <p className="text-brillia-secondary font-inter-medium">Pinhalão – PR</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-sm border border-border">
              <h3 className="text-xl font-inter-semibold text-brillia-primary mb-4">
                Siga-nos nas Redes Sociais
              </h3>
              
              <div className="flex space-x-4">
                <a 
                  href="https://instagram.com/brilliacode" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-12 h-12 bg-brillia-card rounded-lg flex items-center justify-center hover:bg-primary hover:text-black transition-smooth"
                >
                  <Instagram className="w-6 h-6" />
                </a>
                <a 
                  href="https://facebook.com/brilliacode" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-12 h-12 bg-brillia-card rounded-lg flex items-center justify-center hover:bg-primary hover:text-black transition-smooth"
                >
                  <Facebook className="w-6 h-6" />
                </a>
              </div>
            </div>
          </div>
          
          <div className="space-y-6">
            <div className="bg-primary p-8 rounded-xl text-black">
              <h3 className="text-2xl font-inter-semibold mb-4">
                Diagnóstico Gratuito
              </h3>
              <p className="font-inter-medium mb-6 leading-relaxed">
                Analisamos sua presença digital atual e montamos um plano personalizado 
                para seu negócio crescer nas redes sociais.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-black rounded-full"></div>
                  <span className="font-inter-medium">Análise completa das suas redes</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-black rounded-full"></div>
                  <span className="font-inter-medium">Estratégia personalizada</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-black rounded-full"></div>
                  <span className="font-inter-medium">Sem compromisso</span>
                </div>
              </div>
            </div>
            
            <Button 
              size="lg"
              asChild
              className="w-full bg-brillia-dark hover:bg-brillia-dark/90 text-primary font-inter-semibold text-lg py-6"
            >
              <a href="https://wa.me/5543988508487" target="_blank" rel="noopener noreferrer">
                Solicitar Diagnóstico Gratuito
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;